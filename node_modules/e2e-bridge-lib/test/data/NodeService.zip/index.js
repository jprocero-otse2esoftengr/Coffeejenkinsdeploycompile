'use strict';

require('http').createServer((req,res) => res.end()).listen(3333);

